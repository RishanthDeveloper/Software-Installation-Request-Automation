import { useState } from 'react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import { api } from '../api.js';
import { useApi } from '../useApi.js';
import { useAuth } from '../auth.jsx';
import { URGENCY_LABELS, formatDate, formatDateTime, requestNumber, ROLE_LABELS, STATUS_LABELS } from '../format.js';
import StatusBadge from '../components/StatusBadge.jsx';
import StageTrack from '../components/StageTrack.jsx';
import { ErrorMessage, LoadingRows, SuccessMessage } from '../components/Feedback.jsx';

const EVENT_TEXT = {
  submit: 'submitted the request',
  manager_approve: 'approved as manager',
  manager_reject: 'rejected as manager',
  it_approve: 'approved for installation',
  it_reject: 'rejected at IT review',
  assign: 'reassigned the installation',
  mark_installed: 'marked it installed',
  close: 'closed the request',
  cancel: 'cancelled the request',
};

const DONE_TEXT = {
  manager_approve: 'Approved. The request has gone to IT.',
  manager_reject: 'Request rejected.',
  it_approve: 'Approved. The installation is now in the queue.',
  it_reject: 'Request rejected.',
  assign: 'Installation reassigned.',
  mark_installed: 'Marked as installed.',
  close: 'Request closed.',
  cancel: 'Request cancelled.',
};

function ActionPanel({ data, onDone }) {
  const { allowedActions: actions, technicians } = data;
  const { user } = useAuth();
  const [note, setNote] = useState('');
  const [assigneeId, setAssigneeId] = useState(String(user.id));
  const [rejecting, setRejecting] = useState(false);
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);

  if (actions.length === 0) return null;

  async function run(action, extra = {}) {
    if (action === 'cancel' && !window.confirm('Cancel this request?')) return;
    setBusy(true);
    setError(null);
    try {
      await api(`/requests/${data.request.id}/actions`, { method: 'POST', body: { action, note, ...extra } });
      setNote('');
      setRejecting(false);
      onDone(DONE_TEXT[action]);
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  }

  const can = (a) => actions.includes(a);
  const approveAction = can('manager_approve') ? 'manager_approve' : can('it_approve') ? 'it_approve' : null;
  const rejectAction = can('manager_reject') ? 'manager_reject' : can('it_reject') ? 'it_reject' : null;
  const technicianSelect = (id) => (
    <select id={id} value={assigneeId} onChange={(e) => setAssigneeId(e.target.value)}>
      {technicians.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
    </select>
  );

  return (
    <section className="panel action-panel">
      <h2>Your action</h2>
      <ErrorMessage error={error} />

      {approveAction && (
        <>
          <label htmlFor="note">Comment {rejecting ? '(required)' : <span className="optional">(optional)</span>}</label>
          <textarea id="note" rows={3} maxLength={1000} value={note} onChange={(e) => setNote(e.target.value)}
            placeholder={rejecting ? 'Explain why so the requester knows what to do next.' : ''} />
          {approveAction === 'it_approve' && !rejecting && (
            <>
              <label htmlFor="assignee">Assign installation to</label>
              {technicianSelect('assignee')}
            </>
          )}
          <div className="form-actions">
            {!rejecting ? (
              <>
                <button type="button" className="button primary" disabled={busy}
                  onClick={() => run(approveAction, approveAction === 'it_approve' ? { assigneeId: Number(assigneeId) } : {})}>
                  Approve
                </button>
                <button type="button" className="button danger-outline" disabled={busy} onClick={() => setRejecting(true)}>
                  Reject…
                </button>
              </>
            ) : (
              <>
                <button type="button" className="button danger" disabled={busy || !note.trim()} onClick={() => run(rejectAction)}>
                  Reject request
                </button>
                <button type="button" className="button" onClick={() => setRejecting(false)}>Back</button>
              </>
            )}
          </div>
        </>
      )}

      {can('mark_installed') && (
        <>
          <label htmlFor="notes">Installation notes (required)</label>
          <textarea id="notes" rows={3} maxLength={1000} value={note} onChange={(e) => setNote(e.target.value)}
            placeholder="Version installed, method, license key reference…" />
          <div className="form-actions">
            <button type="button" className="button primary" disabled={busy || !note.trim()} onClick={() => run('mark_installed')}>
              Mark installed
            </button>
          </div>
        </>
      )}

      {can('assign') && technicians.length > 1 && (
        <div className="inline-form">
          <label htmlFor="reassign">Reassign to</label>
          {technicianSelect('reassign')}
          <button type="button" className="button" disabled={busy} onClick={() => run('assign', { assigneeId: Number(assigneeId) })}>
            Reassign
          </button>
        </div>
      )}

      {can('close') && (
        <div className="form-actions">
          <p className="muted">If the software works on your computer, close the request.</p>
          <button type="button" className="button primary" disabled={busy} onClick={() => run('close')}>Close request</button>
        </div>
      )}

      {can('cancel') && (
        <div className="form-actions">
          <button type="button" className="button danger-outline" disabled={busy} onClick={() => run('cancel')}>
            Cancel request
          </button>
        </div>
      )}
    </section>
  );
}

export default function RequestDetail() {
  const { id } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const { data, error, loading, reload } = useApi(`/requests/${id}`);
  const [message, setMessage] = useState(location.state?.justCreated ? 'Request submitted. Your manager has been asked to approve it.' : '');

  if (loading && !data) return <div className="page"><LoadingRows rows={6} /></div>;
  if (error) {
    return (
      <div className="page">
        <ErrorMessage error={error} onRetry={error.status === 404 ? undefined : reload} />
        <Link to="/requests">Back to my requests</Link>
      </div>
    );
  }

  const r = data.request;

  return (
    <div className="page">
      <button type="button" className="link-button back" onClick={() => navigate(-1)}>Back</button>
      <div className="page-head">
        <div>
          <h1>{r.softwareName}{r.version ? ` ${r.version}` : ''}</h1>
          <p className="muted">Request {requestNumber(r.id)}, submitted {formatDateTime(r.createdAt)}</p>
        </div>
        <StatusBadge status={r.status} />
      </div>

      <SuccessMessage>{message}</SuccessMessage>
      <StageTrack request={r} />

      {r.status === 'rejected' && (
        <div className="alert alert-error">
          <strong>Reason for rejection:</strong> {r.rejectionReason}
        </div>
      )}

      <div className="detail-grid">
        <section className="panel">
          <h2>Details</h2>
          <dl className="facts">
            <dt>Requested by</dt><dd>{r.requesterName} <span className="muted">({r.requesterEmail})</span></dd>
            <dt>Department</dt><dd>{r.departmentName}</dd>
            <dt>Software</dt><dd>{r.softwareName} <span className="muted">by {r.softwareVendor}</span>{r.requiresLicense ? ', licensed' : ''}</dd>
            <dt>Computer</dt><dd>{r.deviceTag}</dd>
            <dt>Urgency</dt><dd>{URGENCY_LABELS[r.urgency]} <span className="muted">(target {r.slaHours} h)</span></dd>
            {r.neededBy && (<><dt>Needed by</dt><dd>{formatDate(r.neededBy)}</dd></>)}
            {r.dueAt && (
              <><dt>Due</dt><dd className={r.overdue ? 'overdue' : undefined}>{formatDateTime(r.dueAt)}{r.overdue ? ' (missed)' : ''}</dd></>
            )}
            {r.assigneeName && (<><dt>Assigned to</dt><dd>{r.assigneeName}</dd></>)}
            {r.installNotes && (<><dt>Installation notes</dt><dd className="prewrap">{r.installNotes}</dd></>)}
          </dl>
          <h3>Reason</h3>
          <p className="prewrap">{r.justification}</p>
        </section>

        <div>
          <ActionPanel data={data} onDone={(text) => { setMessage(text); reload(); }} />
          <section className="panel">
            <h2>History</h2>
            <ul className="history">
              {data.events.map((e) => (
                <li key={e.id}>
                  <p>
                    <strong>{e.actorName}</strong> <span className="muted">({ROLE_LABELS[e.actorRole]})</span> {EVENT_TEXT[e.action] ?? e.action}
                  </p>
                  {e.note && <p className="history-note prewrap">{e.note}</p>}
                  <p className="history-time">
                    {formatDateTime(e.createdAt)}
                    {e.toStatus !== e.fromStatus && `. Status: ${STATUS_LABELS[e.toStatus]}`}
                  </p>
                </li>
              ))}
            </ul>
          </section>
        </div>
      </div>
    </div>
  );
}
