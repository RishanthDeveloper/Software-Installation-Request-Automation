import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { homePath, useAuth } from '../auth.jsx';
import { ErrorMessage } from '../components/Feedback.jsx';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const user = await login(form.email, form.password);
      navigate(location.state?.from || homePath(user), { replace: true });
    } catch (err) {
      setError(err);
      setBusy(false);
    }
  }

  return (
    <div className="auth-page">
      <form className="auth-box" onSubmit={submit}>
        <h1>Sign in</h1>
        <p className="muted">Request software for your work computer and follow its approval.</p>
        <ErrorMessage error={error} />

        <label htmlFor="email">Work email</label>
        <input id="email" type="email" autoComplete="username" required
          value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />

        <label htmlFor="password">Password</label>
        <input id="password" type="password" autoComplete="current-password" required
          value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />

        <button type="submit" className="button primary" disabled={busy}>
          {busy ? 'Signing in…' : 'Sign in'}
        </button>
        <p className="auth-switch">New here? <Link to="/register">Create an account</Link></p>
      </form>
    </div>
  );
}
