import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth.jsx';
import { ROLE_LABELS } from '../format.js';

const NAV = [
  { to: '/requests', label: 'My requests', exact: true },
  { to: '/requests/new', label: 'Request software' },
  { to: '/approvals', label: 'Approvals', roles: ['manager', 'admin'] },
  { to: '/queue', label: 'Install queue', roles: ['it_support', 'admin'] },
  { to: '/reports', label: 'Reports', roles: ['manager', 'it_support', 'admin'] },
];

const ADMIN_NAV = [
  { to: '/admin/requests', label: 'All requests' },
  { to: '/admin/software', label: 'Software catalog' },
  { to: '/admin/users', label: 'Users' },
  { to: '/admin/audit', label: 'Audit log' },
];

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const visible = NAV.filter((item) => !item.roles || item.roles.includes(user.role));

  async function signOut() {
    await logout();
    navigate('/login');
  }

  return (
    <div className="shell">
      <header className="topbar">
        <span className="brand">Software Requests</span>
        <div className="topbar-user">
          <span>
            {user.name}
            <span className="muted"> ({ROLE_LABELS[user.role]}{user.departmentName ? `, ${user.departmentName}` : ''})</span>
          </span>
          <button type="button" className="link-button" onClick={signOut}>Sign out</button>
        </div>
      </header>

      <nav className="sidebar" aria-label="Main">
        <ul>
          {visible.map((item) => (
            <li key={item.to}>
              <NavLink to={item.to} end={item.exact}>{item.label}</NavLink>
            </li>
          ))}
        </ul>
        {user.role === 'admin' && (
          <>
            <p className="nav-group">Administration</p>
            <ul>
              {ADMIN_NAV.map((item) => (
                <li key={item.to}><NavLink to={item.to}>{item.label}</NavLink></li>
              ))}
            </ul>
          </>
        )}
      </nav>

      <main className="content">
        <Outlet />
      </main>
    </div>
  );
}
