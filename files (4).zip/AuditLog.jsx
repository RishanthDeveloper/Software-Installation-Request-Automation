import { useApi } from '../useApi.js';
import { formatDateTime } from '../format.js';
import { ErrorMessage, LoadingRows } from '../components/Feedback.jsx';

const ACTION_TEXT = {
  'user.registered': 'Account created',
  'user.updated': 'User changed',
  'software.created': 'Software added',
  'software.updated': 'Software changed',
};

function describe(details) {
  if (!details) return '';
  const changes = details.changes ?? details;
  return Object.entries(changes)
    .map(([key, value]) => `${key}: ${value === null ? 'none' : value}`)
    .join(', ');
}

export default function AuditLog() {
  const { data, error, loading, reload } = useApi('/admin/audit');

  return (
    <div className="page">
      <h1>Audit log</h1>
      <p className="muted">Account and catalog changes. Request decisions are recorded in each request’s history.</p>
      <ErrorMessage error={error} onRetry={reload} />
      {loading && !data && <LoadingRows />}
      {data && data.entries.length === 0 && <div className="empty"><p>No changes recorded yet.</p></div>}
      {data && data.entries.length > 0 && (
        <div className="table-wrap">
          <table>
            <thead><tr><th>When</th><th>Who</th><th>What</th><th>Target</th><th>Details</th></tr></thead>
            <tbody>
              {data.entries.map((e) => (
                <tr key={e.id}>
                  <td>{formatDateTime(e.createdAt)}</td>
                  <td>{e.actorName ?? 'System'}</td>
                  <td>{ACTION_TEXT[e.action] ?? e.action}</td>
                  <td>{e.target}</td>
                  <td className="details-cell">{describe(e.details)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
