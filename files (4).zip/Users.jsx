import { useState } from 'react';
import { api } from '../api.js';
import { useApi } from '../useApi.js';
import { useAuth } from '../auth.jsx';
import { ROLE_LABELS, formatDate } from '../format.js';
import { ErrorMessage, LoadingRows, SuccessMessage } from '../components/Feedback.jsx';

function UserRow({ person, departments, isSelf, onSaved }) {
  const [role, setRole] = useState(person.role);
  const [departmentId, setDepartmentId] = useState(person.departmentId ?? '');
  const [error, setError] = useState(null);
  const changed = role !== person.role || String(departmentId) !== String(person.departmentId ?? '');

  async function save(extra = {}) {
    setError(null);
    try {
      await api(`/admin/users/${person.id}`, {
        method: 'PATCH',
        body: { role, departmentId: departmentId === '' ? null : Number(departmentId), ...extra },
      });
      onSaved(`${person.name} updated.`);
    } catch (err) {
      setError(err);
    }
  }

  return (
    <tr className={person.isActive ? undefined : 'inactive'}>
      <td>{person.name}{isSelf && <span className="muted"> (you)</span>}<br /><span className="muted">{person.email}</span></td>
      <td>
        <select value={role} disabled={isSelf} aria-label={`Role for ${person.name}`} onChange={(e) => setRole(e.target.value)}>
          {Object.entries(ROLE_LABELS).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
        </select>
      </td>
      <td>
        <select value={departmentId} aria-label={`Department for ${person.name}`} onChange={(e) => setDepartmentId(e.target.value)}>
          <option value="">None</option>
          {departments.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
        </select>
      </td>
      <td>{formatDate(person.createdAt)}</td>
      <td>
        {changed && <button type="button" className="button small primary" onClick={() => save()}>Save</button>}
        {!isSelf && !changed && (
          <button type="button" className="link-button" onClick={() => save({ isActive: !person.isActive })}>
            {person.isActive ? 'Deactivate' : 'Reactivate'}
          </button>
        )}
        {error && <span className="field-error">{error.message}</span>}
      </td>
    </tr>
  );
}

export default function Users() {
  const { user } = useAuth();
  const users = useApi('/admin/users');
  const departments = useApi('/departments');
  const [message, setMessage] = useState('');

  return (
    <div className="page">
      <h1>Users</h1>
      <p className="muted">
        Managers approve requests from their own department. Role changes apply immediately, even for people already signed in.
      </p>
      <SuccessMessage>{message}</SuccessMessage>
      <ErrorMessage error={users.error || departments.error} onRetry={users.reload} />
      {users.loading && !users.data && <LoadingRows />}
      {users.data && departments.data && (
        <div className="table-wrap">
          <table>
            <thead><tr><th>Name</th><th>Role</th><th>Department</th><th>Joined</th><th /></tr></thead>
            <tbody>
              {users.data.users.map((person) => (
                <UserRow
                  key={`${person.id}-${person.role}-${person.departmentId}-${person.isActive}`}
                  person={person}
                  departments={departments.data.departments}
                  isSelf={person.id === user.id}
                  onSaved={(text) => { setMessage(text); users.reload(); }}
                />
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
