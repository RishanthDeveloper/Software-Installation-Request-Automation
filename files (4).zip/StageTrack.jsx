import { formatDateTime } from '../format.js';

// Shows where a request is in the approval process, with the time each step finished.
export default function StageTrack({ request }) {
  const { status } = request;
  const rejectedAtManager = status === 'rejected' && !request.itDecidedAt;
  const rejectedAtIT = status === 'rejected' && Boolean(request.itDecidedAt);

  const stages = [
    { key: 'submitted', label: 'Submitted', at: request.createdAt, done: true },
    {
      key: 'manager',
      label: rejectedAtManager ? 'Rejected by manager' : 'Manager approval',
      at: request.managerDecidedAt,
      done: Boolean(request.managerDecidedAt),
      failed: rejectedAtManager,
      current: status === 'pending_manager',
    },
    {
      key: 'it',
      label: rejectedAtIT ? 'Rejected by IT' : 'IT approval',
      at: request.itDecidedAt,
      done: Boolean(request.itDecidedAt),
      failed: rejectedAtIT,
      current: status === 'pending_it',
    },
    {
      key: 'installed',
      label: 'Installed',
      at: request.installedAt,
      done: Boolean(request.installedAt),
      current: status === 'in_progress',
    },
    { key: 'closed', label: 'Closed', at: request.closedAt, done: Boolean(request.closedAt), current: status === 'installed' },
  ];

  const stopped = status === 'rejected' || status === 'cancelled';

  return (
    <ol className="stages">
      {stages.map((stage) => {
        let state = 'upcoming';
        if (stage.failed) state = 'failed';
        else if (stage.done) state = 'done';
        else if (stage.current && status === 'cancelled') state = 'stopped';
        else if (stage.current) state = 'current';
        else if (stopped) state = 'skipped';

        return (
          <li key={stage.key} className={`stage stage-${state}`}>
            <span className="stage-mark" aria-hidden="true" />
            <span className="stage-label">{stage.label}</span>
            <span className="stage-time">
              {stage.at ? formatDateTime(stage.at) : state === 'current' ? 'In progress' : state === 'stopped' ? 'Cancelled' : ''}
            </span>
          </li>
        );
      })}
    </ol>
  );
}
