import { useState } from 'react';
import { api } from '../api.js';
import { useApi } from '../useApi.js';
import { ErrorMessage, LoadingRows, SuccessMessage } from '../components/Feedback.jsx';

const EMPTY = { name: '', vendor: '', category: '', requiresLicense: false, licenseCount: '' };

function SoftwareRow({ item, onSaved }) {
  const [licenseCount, setLicenseCount] = useState(item.licenseCount ?? '');
  const [error, setError] = useState(null);

  async function save(changes) {
    setError(null);
    try {
      await api(`/software/${item.id}`, { method: 'PATCH', body: changes });
      onSaved(`${item.name} updated.`);
    } catch (err) {
      setError(err);
    }
  }

  const countChanged = String(licenseCount) !== String(item.licenseCount ?? '');

  return (
    <tr className={item.isActive ? undefined : 'inactive'}>
      <td>{item.name}<br /><span className="muted">{item.vendor}</span></td>
      <td>{item.category}</td>
      <td>{item.requiresLicense ? 'Yes' : 'No'}</td>
      <td>
        <div className="inline-form">
          <input type="number" min="0" className="small" aria-label={`License count for ${item.name}`}
            placeholder="Unlimited" value={licenseCount} onChange={(e) => setLicenseCount(e.target.value)} />
          {countChanged && (
            <button type="button" className="button small"
              onClick={() => save({ licenseCount: licenseCount === '' ? null : Number(licenseCount) })}>Save</button>
          )}
        </div>
        {error && <span className="field-error">{error.message}</span>}
      </td>
      <td>{item.licensesInUse}</td>
      <td>
        <button type="button" className="link-button" onClick={() => save({ isActive: !item.isActive })}>
          {item.isActive ? 'Hide from catalog' : 'Show in catalog'}
        </button>
      </td>
    </tr>
  );
}

export default function SoftwareCatalog() {
  const { data, error, loading, reload } = useApi('/software?all=1');
  const [form, setForm] = useState(EMPTY);
  const [formError, setFormError] = useState(null);
  const [message, setMessage] = useState('');

  async function add(e) {
    e.preventDefault();
    setFormError(null);
    try {
      await api('/software', {
        method: 'POST',
        body: {
          ...form,
          licenseCount: form.requiresLicense && form.licenseCount !== '' ? Number(form.licenseCount) : null,
        },
      });
      setMessage(`${form.name} added to the catalog.`);
      setForm(EMPTY);
      reload();
    } catch (err) {
      setFormError(err);
    }
  }

  const saved = (text) => { setMessage(text); reload(); };

  return (
    <div className="page">
      <h1>Software catalog</h1>
      <p className="muted">Hidden titles can’t be requested, but existing requests keep working.</p>
      <SuccessMessage>{message}</SuccessMessage>
      <ErrorMessage error={error} onRetry={reload} />
      {loading && !data && <LoadingRows />}

      {data && (
        <div className="table-wrap">
          <table>
            <thead>
              <tr><th>Software</th><th>Category</th><th>Paid license</th><th>Licenses owned</th><th>In use</th><th /></tr>
            </thead>
            <tbody>
              {data.software.map((item) => (
                <SoftwareRow key={`${item.id}-${item.licenseCount}-${item.isActive}`} item={item} onSaved={saved} />
              ))}
            </tbody>
          </table>
        </div>
      )}

      <section className="panel narrow">
        <h2>Add software</h2>
        <ErrorMessage error={formError} />
        <form className="form" onSubmit={add}>
          <div className="form-row">
            <div>
              <label htmlFor="sw-name">Name</label>
              <input id="sw-name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </div>
            <div>
              <label htmlFor="sw-vendor">Vendor</label>
              <input id="sw-vendor" required value={form.vendor} onChange={(e) => setForm({ ...form, vendor: e.target.value })} />
            </div>
          </div>
          <div className="form-row">
            <div>
              <label htmlFor="sw-category">Category</label>
              <input id="sw-category" required list="categories" value={form.category}
                onChange={(e) => setForm({ ...form, category: e.target.value })} />
              <datalist id="categories">
                {[...new Set(data?.software.map((s) => s.category) ?? [])].map((c) => <option key={c} value={c} />)}
              </datalist>
            </div>
            <div>
              <label className="checkbox">
                <input type="checkbox" checked={form.requiresLicense}
                  onChange={(e) => setForm({ ...form, requiresLicense: e.target.checked })} />
                Needs a paid license
              </label>
              {form.requiresLicense && (
                <>
                  <label htmlFor="sw-count">Licenses owned</label>
                  <input id="sw-count" type="number" min="0" placeholder="Leave empty for unlimited"
                    value={form.licenseCount} onChange={(e) => setForm({ ...form, licenseCount: e.target.value })} />
                </>
              )}
            </div>
          </div>
          <div className="form-actions">
            <button type="submit" className="button primary">Add software</button>
          </div>
        </form>
      </section>
    </div>
  );
}
