import { useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import { useApi } from '../useApi.js';
import { requestNumber } from '../format.js';
import { ErrorMessage, LoadingRows } from '../components/Feedback.jsx';

const LICENSED_MIN = 30;

export default function NewRequest() {
  const navigate = useNavigate();
  const catalog = useApi('/software');
  const [form, setForm] = useState({
    softwareId: '', version: '', deviceTag: '', urgency: 'normal', neededBy: '', justification: '',
  });
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);

  const software = catalog.data?.software ?? [];
  const selected = software.find((s) => String(s.id) === form.softwareId);
  const minReason = selected?.requiresLicense ? LICENSED_MIN : 10;

  const byCategory = useMemo(() => {
    const groups = {};
    software.forEach((s) => { (groups[s.category] ||= []).push(s); });
    return groups;
  }, [software]);

  const update = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const { id } = await api('/requests', {
        method: 'POST',
        body: { ...form, softwareId: Number(form.softwareId) },
      });
      navigate(`/requests/${id}`, { state: { justCreated: true } });
    } catch (err) {
      setError(err);
      setBusy(false);
    }
  }

  if (catalog.loading) return <div className="page"><h1>Request software</h1><LoadingRows /></div>;

  const noLicensesLeft = selected?.licenseCount !== null && selected?.licensesInUse >= selected?.licenseCount;

  return (
    <div className="page narrow">
      <h1>Request software</h1>
      <p className="muted">Your manager approves the request first, then IT checks licensing and installs it.</p>

      <ErrorMessage error={catalog.error} onRetry={catalog.reload} />
      {error && (
        <div className="alert alert-error" role="alert">
          {error.message}
          {error.details?.existingId && (
            <> <Link to={`/requests/${error.details.existingId}`}>Open {requestNumber(error.details.existingId)}</Link></>
          )}
        </div>
      )}

      <form className="form" onSubmit={submit}>
        <label htmlFor="software">Software</label>
        <select id="software" required value={form.softwareId} onChange={update('softwareId')}>
          <option value="">Choose…</option>
          {Object.entries(byCategory).map(([category, items]) => (
            <optgroup key={category} label={category}>
              {items.map((s) => <option key={s.id} value={s.id}>{s.name} ({s.vendor})</option>)}
            </optgroup>
          ))}
        </select>

        {selected?.requiresLicense && (
          <p className="callout">
            {selected.name} needs a paid license.
            {selected.licenseCount !== null && ` ${selected.licensesInUse} of ${selected.licenseCount} licenses are in use.`}
            {noLicensesLeft && ' None are free right now, so IT may not be able to approve this until one is released.'}
          </p>
        )}

        <div className="form-row">
          <div>
            <label htmlFor="version">Version <span className="optional">(optional)</span></label>
            <input id="version" value={form.version} onChange={update('version')} placeholder="Latest" maxLength={40} />
          </div>
          <div>
            <label htmlFor="device">Computer asset tag</label>
            <input id="device" required value={form.deviceTag} onChange={update('deviceTag')} maxLength={40}
              aria-describedby="device-hint" />
            <p id="device-hint" className="hint">Printed on the sticker under your laptop, for example LT-0042.</p>
          </div>
        </div>

        <div className="form-row">
          <fieldset>
            <legend>Urgency</legend>
            {[['low', 'Low'], ['normal', 'Normal'], ['high', 'High']].map(([value, label]) => (
              <label key={value} className="radio">
                <input type="radio" name="urgency" value={value} checked={form.urgency === value} onChange={update('urgency')} />
                {label}
              </label>
            ))}
          </fieldset>
          <div>
            <label htmlFor="needed">Needed by <span className="optional">(optional)</span></label>
            <input id="needed" type="date" value={form.neededBy} onChange={update('neededBy')}
              min={new Date().toISOString().slice(0, 10)} />
          </div>
        </div>

        <label htmlFor="justification">Why do you need it?</label>
        <textarea id="justification" required rows={5} maxLength={1000} value={form.justification}
          onChange={update('justification')} aria-describedby="reason-hint" />
        <p id="reason-hint" className="hint">
          {form.justification.trim().length} characters, at least {minReason} needed. Mention the project or task it’s for.
        </p>

        <div className="form-actions">
          <button type="submit" className="button primary" disabled={busy}>
            {busy ? 'Submitting…' : 'Submit request'}
          </button>
          <Link to="/requests" className="button">Cancel</Link>
        </div>
      </form>
    </div>
  );
}
