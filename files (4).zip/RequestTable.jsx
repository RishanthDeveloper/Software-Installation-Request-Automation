import { Link } from 'react-router-dom';
import StatusBadge from './StatusBadge.jsx';
import { URGENCY_LABELS, formatDate, requestNumber, timeAgo } from '../format.js';

// Columns can be switched on per page, so each list only shows what matters there.
export default function RequestTable({ requests, show = {} }) {
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Request</th>
            <th>Software</th>
            {show.requester && <th>Requested by</th>}
            {show.department && <th>Department</th>}
            <th>Status</th>
            <th>Urgency</th>
            {show.assignee && <th>Assigned to</th>}
            <th>Submitted</th>
            {show.due && <th>Due</th>}
            {show.updated && <th>Last update</th>}
          </tr>
        </thead>
        <tbody>
          {requests.map((r) => (
            <tr key={r.id}>
              <td><Link to={`/requests/${r.id}`}>{requestNumber(r.id)}</Link></td>
              <td>{r.softwareName}{r.version ? <span className="muted"> {r.version}</span> : null}</td>
              {show.requester && <td>{r.requesterName}</td>}
              {show.department && <td>{r.departmentName}</td>}
              <td><StatusBadge status={r.status} /></td>
              <td className={r.urgency === 'high' ? 'urgent' : undefined}>{URGENCY_LABELS[r.urgency]}</td>
              {show.assignee && <td>{r.assigneeName || <span className="muted">Not assigned</span>}</td>}
              <td>{formatDate(r.createdAt)}</td>
              {show.due && (
                <td className={r.overdue ? 'overdue' : undefined}>
                  {r.dueAt ? formatDate(r.dueAt) : ''}
                  {r.overdue && r.status !== 'closed' && r.status !== 'installed' ? ' (overdue)' : ''}
                </td>
              )}
              {show.updated && <td>{timeAgo(r.updatedAt)}</td>}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
