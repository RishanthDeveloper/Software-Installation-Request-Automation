export function ErrorMessage({ error, onRetry }) {
  if (!error) return null;
  return (
    <div className="alert alert-error" role="alert">
      {error.message}
      {onRetry && (
        <button type="button" className="link-button" onClick={onRetry}>Try again</button>
      )}
    </div>
  );
}

export function SuccessMessage({ children }) {
  if (!children) return null;
  return <div className="alert alert-success" role="status">{children}</div>;
}

export function LoadingRows({ rows = 4 }) {
  return (
    <div className="skeleton" aria-label="Loading">
      {Array.from({ length: rows }, (_, i) => <div key={i} className="skeleton-row" />)}
    </div>
  );
}
