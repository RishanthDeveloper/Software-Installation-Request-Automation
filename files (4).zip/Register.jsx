import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { homePath, useAuth } from '../auth.jsx';
import { useApi } from '../useApi.js';
import { ErrorMessage } from '../components/Feedback.jsx';

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const departments = useApi('/departments');
  const [form, setForm] = useState({ name: '', email: '', departmentId: '', password: '', confirm: '' });
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);

  const update = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  async function submit(e) {
    e.preventDefault();
    if (form.password !== form.confirm) {
      setError(new Error('The two passwords don’t match.'));
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const user = await register({
        name: form.name,
        email: form.email,
        password: form.password,
        departmentId: Number(form.departmentId),
      });
      navigate(homePath(user), { replace: true });
    } catch (err) {
      setError(err);
      setBusy(false);
    }
  }

  return (
    <div className="auth-page">
      <form className="auth-box" onSubmit={submit}>
        <h1>Create an account</h1>
        <p className="muted">New accounts start as employees. An admin can change your role later.</p>
        <ErrorMessage error={error || departments.error} />

        <label htmlFor="name">Full name</label>
        <input id="name" autoComplete="name" required value={form.name} onChange={update('name')} />

        <label htmlFor="email">Work email</label>
        <input id="email" type="email" autoComplete="email" required value={form.email} onChange={update('email')} />

        <label htmlFor="department">Department</label>
        <select id="department" required value={form.departmentId} onChange={update('departmentId')}>
          <option value="">Choose…</option>
          {departments.data?.departments.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
        </select>

        <label htmlFor="password">Password</label>
        <input id="password" type="password" autoComplete="new-password" required minLength={8}
          value={form.password} onChange={update('password')} aria-describedby="password-hint" />
        <p id="password-hint" className="hint">At least 8 characters, with a letter and a number.</p>

        <label htmlFor="confirm">Confirm password</label>
        <input id="confirm" type="password" autoComplete="new-password" required
          value={form.confirm} onChange={update('confirm')} />

        <button type="submit" className="button primary" disabled={busy}>
          {busy ? 'Creating account…' : 'Create account'}
        </button>
        <p className="auth-switch">Already registered? <Link to="/login">Sign in</Link></p>
      </form>
    </div>
  );
}
