import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useApi } from '../useApi.js';
import { STATUS_LABELS } from '../format.js';
import RequestTable from '../components/RequestTable.jsx';
import { ErrorMessage, LoadingRows } from '../components/Feedback.jsx';

export default function MyRequests() {
  const [status, setStatus] = useState('');
  const { data, error, loading, reload } = useApi(`/requests?view=mine${status ? `&status=${status}` : ''}`);

  return (
    <div className="page">
      <div className="page-head">
        <h1>My requests</h1>
        <Link to="/requests/new" className="button primary">Request software</Link>
      </div>

      <div className="filters">
        <label htmlFor="status-filter">Status</label>
        <select id="status-filter" value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">All</option>
          {Object.entries(STATUS_LABELS).map(([value, label]) => <option key={value} value={value}>{label}</option>)}
        </select>
      </div>

      <ErrorMessage error={error} onRetry={reload} />
      {loading && <LoadingRows />}
      {data && data.requests.length === 0 && (
        <div className="empty">
          {status
            ? <p>None of your requests have this status.</p>
            : <p>You haven’t requested any software yet. <Link to="/requests/new">Make your first request</Link>.</p>}
        </div>
      )}
      {data && data.requests.length > 0 && <RequestTable requests={data.requests} show={{ updated: true }} />}
    </div>
  );
}
