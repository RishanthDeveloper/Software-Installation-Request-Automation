import { useApi } from '../useApi.js';
import { formatHours } from '../format.js';
import { ErrorMessage, LoadingRows } from '../components/Feedback.jsx';

const monthName = new Intl.DateTimeFormat('en-IN', { month: 'short', year: 'numeric' });

function BarList({ rows, labelKey = 'name', valueKey = 'requests' }) {
  const max = Math.max(1, ...rows.map((r) => r[valueKey]));
  return (
    <ul className="bars">
      {rows.map((row) => (
        <li key={row[labelKey]}>
          <span className="bar-label">{row.displayLabel ?? row[labelKey]}</span>
          <span className="bar-track">
            <span className="bar-fill" style={{ width: `${(row[valueKey] / max) * 100}%` }} />
          </span>
          <span className="bar-value">{row[valueKey]}</span>
        </li>
      ))}
    </ul>
  );
}

export default function Reports() {
  const { data, error, loading, reload } = useApi('/stats');

  if (loading && !data) return <div className="page"><h1>Reports</h1><LoadingRows rows={6} /></div>;
  if (error) return <div className="page"><h1>Reports</h1><ErrorMessage error={error} onRetry={reload} /></div>;

  const { totals, averageHours, sla, topSoftware, byMonth, byDepartment } = data;
  const months = byMonth.map((m) => ({ ...m, displayLabel: monthName.format(new Date(`${m.month}-01T00:00:00`)) }));

  const figures = [
    ['Total requests', totals.all],
    ['Waiting for manager', totals.waitingForManager],
    ['Waiting for IT', totals.waitingForIT],
    ['Installing', totals.installing],
    ['Completed', totals.completed],
    ['Rejected', totals.rejected],
  ];

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <h1>Reports</h1>
          <p className="muted">{data.scope}. Figures are calculated from request timestamps each time this page loads.</p>
        </div>
        <button type="button" className="button" onClick={reload}>Refresh</button>
      </div>

      <dl className="figures">
        {figures.map(([label, value]) => (
          <div key={label}>
            <dt>{label}</dt>
            <dd>{value}</dd>
          </div>
        ))}
      </dl>

      {totals.all === 0 ? (
        <div className="empty"><p>No requests yet. Reports fill in as requests are submitted and approved.</p></div>
      ) : (
        <div className="report-grid">
          <section className="panel">
            <h2>Service level</h2>
            <p className="big-figure">
              {sla.compliancePercent === null ? 'No installs yet' : `${sla.compliancePercent}%`}
            </p>
            <p className="muted">
              {sla.finished > 0
                ? `${sla.met} of ${sla.finished} installs finished within target.`
                : 'Compliance appears once installs are completed.'}
            </p>
            <p className={sla.overdueOpen ? 'overdue' : 'muted'}>
              {sla.overdueOpen} open request{sla.overdueOpen === 1 ? ' is' : 's are'} past target now.
            </p>
            <p className="hint">
              Targets from submission to install: {sla.targets.map((t) => `${t.urgency} ${t.hours} h`).join(', ')}.
            </p>
          </section>

          <section className="panel">
            <h2>Average time per step</h2>
            <dl className="facts">
              <dt>Manager decision</dt><dd>{formatHours(averageHours.managerDecision)}</dd>
              <dt>IT decision</dt><dd>{formatHours(averageHours.itDecision)}</dd>
              <dt>Installation</dt><dd>{formatHours(averageHours.installation)}</dd>
              <dt>Submitted to installed</dt><dd>{formatHours(averageHours.submitToInstalled)}</dd>
            </dl>
          </section>

          <section className="panel">
            <h2>Most requested software</h2>
            <BarList rows={topSoftware} />
          </section>

          <section className="panel">
            <h2>Requests per month</h2>
            <BarList rows={months} labelKey="month" />
          </section>

          {byDepartment.length > 1 && (
            <section className="panel">
              <h2>By department</h2>
              <BarList rows={byDepartment} />
            </section>
          )}
        </div>
      )}
    </div>
  );
}
