import { useState } from 'react';
import { useApi } from '../useApi.js';
import { useAuth } from '../auth.jsx';
import RequestTable from '../components/RequestTable.jsx';
import { ErrorMessage, LoadingRows } from '../components/Feedback.jsx';

const SECTIONS = [
  { status: 'pending_it', title: 'Waiting for IT approval', empty: 'No requests are waiting for IT approval.' },
  { status: 'in_progress', title: 'To install', empty: 'Nothing to install right now.' },
  { status: 'installed', title: 'Installed, waiting for the employee to close', empty: 'No installs are waiting to be closed.' },
];

export default function Queue() {
  const { user } = useAuth();
  const [mineOnly, setMineOnly] = useState(false);
  const { data, error, loading, reload } = useApi('/requests?view=queue');

  const requests = (data?.requests ?? []).filter((r) => !mineOnly || r.assignedTo === user.id);
  const overdue = requests.filter((r) => r.overdue && r.status !== 'installed').length;

  return (
    <div className="page">
      <div className="page-head">
        <h1>Install queue</h1>
        <button type="button" className="button" onClick={reload}>Refresh</button>
      </div>

      <div className="filters">
        <label className="checkbox">
          <input type="checkbox" checked={mineOnly} onChange={(e) => setMineOnly(e.target.checked)} />
          Only show installs assigned to me
        </label>
        {overdue > 0 && <span className="overdue">{overdue} past their due time</span>}
      </div>

      <ErrorMessage error={error} onRetry={reload} />
      {loading && <LoadingRows />}
      {data && SECTIONS.map((section) => {
        const rows = requests.filter((r) => r.status === section.status);
        return (
          <section key={section.status} className="queue-section">
            <h2>{section.title} <span className="muted">({rows.length})</span></h2>
            {rows.length === 0
              ? <p className="muted">{section.empty}</p>
              : <RequestTable requests={rows} show={{ requester: true, department: true, assignee: section.status !== 'pending_it', due: true }} />}
          </section>
        );
      })}
    </div>
  );
}
