import { useEffect, useState } from 'react';
import { useApi } from '../useApi.js';
import { STATUS_LABELS } from '../format.js';
import RequestTable from '../components/RequestTable.jsx';
import { ErrorMessage, LoadingRows } from '../components/Feedback.jsx';

export default function AllRequests() {
  const [status, setStatus] = useState('');
  const [search, setSearch] = useState('');
  const [query, setQuery] = useState('');

  // Wait until typing pauses before searching.
  useEffect(() => {
    const t = setTimeout(() => setQuery(search.trim()), 300);
    return () => clearTimeout(t);
  }, [search]);

  const params = new URLSearchParams({ view: 'all' });
  if (status) params.set('status', status);
  if (query) params.set('q', query);
  const { data, error, loading, reload } = useApi(`/requests?${params}`);

  return (
    <div className="page">
      <h1>All requests</h1>
      <div className="filters">
        <label htmlFor="search">Search</label>
        <input id="search" type="search" placeholder="Software or person" value={search} onChange={(e) => setSearch(e.target.value)} />
        <label htmlFor="status">Status</label>
        <select id="status" value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">All</option>
          {Object.entries(STATUS_LABELS).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
        </select>
      </div>

      <ErrorMessage error={error} onRetry={reload} />
      {loading && !data && <LoadingRows />}
      {data && data.requests.length === 0 && <div className="empty"><p>No requests match these filters.</p></div>}
      {data && data.requests.length > 0 && (
        <>
          <p className="count">{data.requests.length} requests</p>
          <RequestTable requests={data.requests} show={{ requester: true, department: true, assignee: true, updated: true }} />
        </>
      )}
    </div>
  );
}
