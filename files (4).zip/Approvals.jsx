import { useApi } from '../useApi.js';
import { useAuth } from '../auth.jsx';
import RequestTable from '../components/RequestTable.jsx';
import { ErrorMessage, LoadingRows } from '../components/Feedback.jsx';

export default function Approvals() {
  const { user } = useAuth();
  const { data, error, loading, reload } = useApi('/requests?view=approvals');
  const count = data?.requests.length ?? 0;

  return (
    <div className="page">
      <h1>Approvals</h1>
      <p className="muted">
        {user.role === 'admin' ? 'Requests from all departments' : `Requests from ${user.departmentName}`} waiting for a manager decision.
        Open a request to approve or reject it.
      </p>

      <ErrorMessage error={error} onRetry={reload} />
      {loading && <LoadingRows />}
      {data && count === 0 && <div className="empty"><p>Nothing is waiting for your approval.</p></div>}
      {count > 0 && (
        <>
          <p className="count">{count} waiting</p>
          <RequestTable requests={data.requests} show={{ requester: true, department: user.role === 'admin', due: true }} />
        </>
      )}
    </div>
  );
}
